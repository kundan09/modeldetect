detectron2.data.transforms 
====================================

Related tutorial: :doc:`../tutorials/augmentation`.

.. automodule:: detectron2.data.transforms
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:
